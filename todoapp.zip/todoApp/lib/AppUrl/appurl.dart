class ApiUrl {


  static const String host_address = 'https://jsonplaceholder.typicode.com/todos';
}