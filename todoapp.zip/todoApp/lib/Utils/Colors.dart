import 'dart:ui';

Color color1 = const Color(0xffFFFFFF);
Color tablecolor12= const Color(0xff4D99FF);
Color color2= const Color(0xffD3E8F2);
